
# TheMealDB
## Meal recipe browser and screensaver for Kodi

![Screenshot program](https://raw.githubusercontent.com/zag2me/script.screensaver.themealdb/master/icon.png)

This addon let you browse dozens of meal recipes, filter by type, area, ingredient and even search youtube videos.
It also includes an interactive screensaver to display random drinks, switch drinks and search specific recipes.

Powered by http://www.themealdb.com

* [Forum url] coming soon...

Textures from script.extendedinfo (by phil)

# Screenshots

Program

![Screenshot program](http://www.themealdb.com/images/github/screenshot-01.jpg)
![Screenshot program](http://www.themealdb.com/images/github/screenshot-02.jpg)
![Screenshot program](http://www.themealdb.com/images/github/screenshot-04.jpg)
![Screenshot program](http://www.themealdb.com/images/github/screenshot-05.jpg)
![Screenshot program](http://www.themealdb.com/images/github/screenshot-06.jpg)


Screensaver

![Screenshot program](http://www.themealdb.com/images/github/screenshot-03.jpg)
